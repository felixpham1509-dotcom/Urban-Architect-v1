import UrbanArchitect from "@/components/urban-architect";

export default function Page() {
  return <UrbanArchitect />;
}
