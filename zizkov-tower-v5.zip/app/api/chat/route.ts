import {
  convertToModelMessages,
  createUIMessageStreamResponse,
  streamText,
  toUIMessageStream,
  type UIMessage,
} from "ai";
import { products, type Lang } from "@/lib/i18n";

export const maxDuration = 30;

const catalog = products
  .map(
    (p) =>
      `- ${p.copy.cs.name} / ${p.copy.en.name} — ${p.category}, ${p.price} CZK, sizes: ${p.sizes.join(", ")}. ${p.copy.en.description}`,
  )
  .join("\n");

function systemPrompt(lang: Lang) {
  const language = lang === "cs" ? "Czech (čeština)" : "English";
  return `You are the AI assistant of URBAN ARCHITECT, a Prague streetwear brand. Current collection: Žižkov Tower Editions (Drop 01), limited to 300 numbered pieces, inspired by the brutalist Žižkov TV Tower (216 m) in Prague 3.

ALWAYS reply in ${language}, regardless of the language the user writes in.
Style: concise (max ~4 short sentences or a short list), confident, minimal, plain text without markdown headings. No emojis.

Catalog (prices in CZK):
${catalog}

Facts:
- Materials: hoodies are heavyweight 510 GSM compact-knit 100% organic cotton, garment-dyed, brushed fleece inside. T-shirts are 240 GSM premium combed cotton. Beanie is ribbed acrylic-wool blend. Tote is heavy cotton canvas.
- Fit: hoodies are oversized with dropped shoulders — size down one size for a regular fit. T-shirts are a boxy relaxed fit, true to size.
- Hoodie chest width (flat): S 60 cm, M 63 cm, L 66 cm, XL 69 cm, XXL 72 cm. Length: S 68, M 70, L 72, XL 74, XXL 76 cm.
- Care: wash inside out at 30 °C, do not tumble dry, do not iron prints.
- Shipping: Czech Republic 99 CZK (Zásilkovna) or 149 CZK (courier), free over 2,000 CZK, delivery 1–3 working days. EU shipping 290 CZK, 3–6 working days.
- Returns: 30 days, unworn items with tags.
- Everything is designed and printed in Prague.

If asked something you do not know (e.g. order status), say so and direct the user to hello@urbanarchitect.cz. Stay on topics related to the store.`;
}

export async function POST(req: Request) {
  const { messages, lang }: { messages: UIMessage[]; lang?: string } = await req.json();
  const safeLang: Lang = lang === "en" ? "en" : "cs";

  const result = streamText({
    model: "openai/gpt-5.4-mini",
    system: systemPrompt(safeLang),
    messages: await convertToModelMessages(messages.slice(-20)),
  });

  return createUIMessageStreamResponse({
    stream: toUIMessageStream({ stream: result.stream }),
  });
}
