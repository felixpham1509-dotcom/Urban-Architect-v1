"use client";

import { useEffect, useState } from "react";
import { AiAssistant } from "@/components/ai-assistant";
import { ArchiveSection } from "@/components/archive-section";
import { ManifestoSection } from "@/components/manifesto-section";
import { ProductModal } from "@/components/product-modal";
import { dict, formatPrice, products, type CategoryKey, type Dict, type Lang, type Product } from "@/lib/i18n";

type IconName =
  | "arrow"
  | "bag"
  | "chevron"
  | "close"
  | "heart"
  | "menu"
  | "minus"
  | "plus"
  | "search";

const photos = {
  hero: "/hero/zizkov-tower-night.png",
  architecture: "/hero/zizkov-tower-night.png",
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    bag: (
      <>
        <path d="M5 8h14l-1 12H6L5 8Z" />
        <path d="M9 8V6a3 3 0 0 1 6 0v2" />
      </>
    ),
    chevron: <path d="m8 10 4 4 4-4" />,
    close: (
      <>
        <path d="m6 6 12 12" />
        <path d="m18 6-12 12" />
      </>
    ),
    heart: (
      <path d="M20.8 5.7a5.5 5.5 0 0 0-7.8 0L12 6.8l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 22l7.8-7.4 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
    ),
    menu: (
      <>
        <path d="M4 8h16" />
        <path d="M4 16h16" />
      </>
    ),
    minus: <path d="M5 12h14" />,
    plus: (
      <>
        <path d="M5 12h14" />
        <path d="M12 5v14" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="6" />
        <path d="m16 16 4 4" />
      </>
    ),
  };

  return (
    <svg aria-hidden="true" fill="none" height={size} viewBox="0 0 24 24" width={size}>
      <g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5">
        {paths[name]}
      </g>
    </svg>
  );
}

function Action({
  children,
  className = "",
  onClick,
  label,
}: {
  children: React.ReactNode;
  className?: string;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  label?: string;
}) {
  return (
    <button aria-label={label} className={`action ${className}`} onClick={onClick} type="button">
      {children}
    </button>
  );
}

function Logo() {
  return (
    <a aria-label="Urban Architect home" className="logo" href="#top">
      URBAN<span className="text-accent">/</span>ARCHITECT
    </a>
  );
}

function DropTimer({ labels, ariaLabel }: { labels: string[]; ariaLabel: string }) {
  const [seconds, setSeconds] = useState(4 * 86400 + 13 * 3600 + 27 * 60 + 8);

  useEffect(() => {
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const values = [
    Math.floor(seconds / 86400),
    Math.floor((seconds % 86400) / 3600),
    Math.floor((seconds % 3600) / 60),
    seconds % 60,
  ];

  return (
    <div className="timer" aria-label={ariaLabel}>
      {values.map((value, index) => (
        <div className="timer-unit" key={index}>
          <span>{String(value).padStart(2, "0")}</span>
          <small>{labels[index]}</small>
          {index < values.length - 1 && <b>:</b>}
        </div>
      ))}
    </div>
  );
}

function LanguageSwitcher({ lang, onChange, label }: { lang: Lang; onChange: (lang: Lang) => void; label: string }) {
  return (
    <div aria-label={label} className="lang-switch" role="group">
      {(["cs", "en"] as const).map((code, index) => (
        <span className="lang-item" key={code}>
          {index > 0 && <span aria-hidden="true" className="lang-divider">|</span>}
          <button
            aria-pressed={lang === code}
            className={lang === code ? "active" : ""}
            lang={code}
            onClick={() => onChange(code)}
            type="button"
          >
            {code === "cs" ? "CZ" : "EN"}
          </button>
        </span>
      ))}
    </div>
  );
}

type Filter = "all" | CategoryKey;

function CategoryFilter({
  active,
  count,
  onChange,
  t,
}: {
  active: Filter;
  count: number;
  onChange: (filter: Filter) => void;
  t: Dict;
}) {
  const filters: Filter[] = ["all", "hoodies", "tees", "accessories"];
  return (
    <div className="filter-bar">
      <div aria-label={t.filterLabel} className="filter-group" role="group">
        {filters.map((filter) => (
          <button
            aria-pressed={active === filter}
            className={active === filter ? "filter-button active" : "filter-button"}
            key={filter}
            onClick={() => onChange(filter)}
            type="button"
          >
            {t.filters[filter]}
          </button>
        ))}
      </div>
      <span className="filter-count">
        {t.productsCount}: <b>{count}</b>
      </span>
    </div>
  );
}

function ProductCard({
  added,
  selectedSize,
  wished,
  onPreview,
  onSelectSize,
  onToggleWishlist,
  product,
  onAdd,
  lang,
  t,
  index,
}: {
  added: boolean;
  selectedSize: string;
  wished: boolean;
  onPreview: () => void;
  onSelectSize: (size: string) => void;
  onToggleWishlist: () => void;
  product: Product;
  onAdd: () => void;
  lang: Lang;
  t: Dict;
  index: number;
}) {
  const copy = product.copy[lang];
  return (
    <article className="product-card filter-in" style={{ animationDelay: `${index * 45}ms` }}>
      <div
        className="product-image"
        onClick={onPreview}
        onKeyDown={(event) => (event.key === "Enter" || event.key === " ") && onPreview()}
        role="button"
        tabIndex={0}
      >
        <img alt={`${copy.name} – Žižkov Tower Editions`} src={product.image} style={{ objectPosition: product.imagePosition }} />
        {product.label && <span className="product-label">{t.labels[product.label]}</span>}
        <Action
          className={wished ? "wishlist-button active" : "wishlist-button"}
          label={t.addWishlist}
          onClick={(event) => {
            event.stopPropagation();
            onToggleWishlist();
          }}
        >
          <Icon name="heart" size={17} />
        </Action>
      </div>
      <div className="product-copy">
        <div>
          <span>{t.filters[product.category]}</span>
          <h3 onClick={onPreview}>{copy.name}</h3>
          <p>{copy.detail}</p>
        </div>
        <strong>{formatPrice(product.price, lang)}</strong>
      </div>
      <div className="size-row">
        {product.sizes.map((size) => (
          <Action
            className={selectedSize === size ? "size-button active" : "size-button"}
            key={size}
            onClick={() => onSelectSize(size)}
          >
            {size}
          </Action>
        ))}
      </div>
      <Action className={added ? "quick-add added" : "quick-add"} onClick={onAdd}>
        {added ? <>{t.added} <span className="added-check">✓</span></> : <>{t.addToCart} <Icon name="bag" size={15} /></>}
      </Action>
    </article>
  );
}

export default function UrbanArchitect() {
  const [lang, setLang] = useState<Lang>("cs");
  const [filter, setFilter] = useState<Filter>("all");
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [look, setLook] = useState(0);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<Record<number, string>>(
    Object.fromEntries(products.map((product) => [product.id, product.sizes[0]])),
  );
  const [cart, setCart] = useState<Array<{ product: Product; size: string; quantity: number }>>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [preview, setPreview] = useState<Product | null>(null);
  const [addedId, setAddedId] = useState<number | null>(null);

  const t = dict[lang];
  const visibleProducts = filter === "all" ? products : products.filter((p) => p.category === filter);
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const subtotal = cart.reduce((total, item) => total + item.product.price * item.quantity, 0);
  const shippingRemaining = Math.max(0, 2000 - subtotal);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    document.body.style.overflow = cartOpen || wishlistOpen || preview ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [cartOpen, wishlistOpen, preview]);

  const toggleWishlist = (productId: number) => {
    setWishlist((current) =>
      current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId],
    );
  };

  const addToCart = (product: Product, sizeOverride?: string) => {
    const size = sizeOverride ?? selectedSizes[product.id];
    setCart((current) => {
      const existing = current.find((item) => item.product.id === product.id && item.size === size);
      return existing
        ? current.map((item) =>
            item.product.id === product.id && item.size === size ? { ...item, quantity: item.quantity + 1 } : item,
          )
        : [...current, { product, size, quantity: 1 }];
    });
    setAddedId(product.id);
    window.setTimeout(() => setAddedId(null), 1100);
    window.setTimeout(() => setCartOpen(true), 180);
  };

  const updateQuantity = (productId: number, size: string, change: number) => {
    setCart((current) =>
      current
        .map((item) =>
          item.product.id === productId && item.size === size ? { ...item, quantity: item.quantity + change } : item,
        )
        .filter((item) => item.quantity > 0),
    );
  };

  const looks = [
    { number: "01", image: "/lookbook/zizkov-tubus.png", ...t.looks[0] },
    { number: "02", image: "/lookbook/praha-vertical.png", ...t.looks[1] },
  ];

  const navItems = [
    { href: "#shop", label: t.nav.drops },
    { href: "#archive", label: t.nav.archive },
    { href: "#about", label: t.nav.materials },
    { href: "#manifesto", label: t.nav.manifesto },
  ];

  return (
    <div className="site-shell" id="top">
      <div className="announcement">
        <span>{t.announcement[0]}</span>
        <span className="announcement-feature">
          <i /> {t.announcement[1]}
        </span>
        <span>{t.announcement[2]}</span>
      </div>

      <header className="nav">
        <Action className="menu-trigger" label={t.toggleMenu} onClick={() => setMenuOpen(!menuOpen)}>
          <Icon name={menuOpen ? "close" : "menu"} />
        </Action>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {navItems.map((item) => (
            <a href={item.href} key={item.href} onClick={() => setMenuOpen(false)}>
              {item.label}
            </a>
          ))}
        </nav>
        <Logo />
        <div className="nav-tools">
          <LanguageSwitcher label={t.language} lang={lang} onChange={setLang} />
          <Action label={t.search} onClick={() => setSearchOpen(true)}>
            <Icon name="search" />
          </Action>
          <Action
            className={wishlist.length ? "cart nav-wishlist active" : "cart nav-wishlist"}
            label={t.wishlist}
            onClick={() => setWishlistOpen(true)}
          >
            <Icon name="heart" />
            <span>{wishlist.length}</span>
          </Action>
          <Action className="cart" label={t.cartItems} onClick={() => setCartOpen(true)}>
            <Icon name="bag" />
            <span>{cartCount}</span>
          </Action>
        </div>
      </header>

      {searchOpen && (
        <div className="search-overlay">
          <div className="search-inner">
            <span>{t.searchLabel}</span>
            <input aria-label={t.searchLabel} autoFocus placeholder={t.searchPlaceholder} type="search" />
            <Action label={t.closeSearch} onClick={() => setSearchOpen(false)}>
              <Icon name="close" size={28} />
            </Action>
          </div>
        </div>
      )}

      <main>
        <section className="hero">
          <img alt={t.heroAlt} className="hero-image" src={photos.hero} />
          <div className="hero-shade" />
          <div className="hero-rail">
            <span><i /> {t.heroRail[0]}</span>
            <span>{t.heroRail[1]}</span>
            <span>{t.heroRail[2]}</span>
          </div>
          <div className="hero-content">
            <div className="eyebrow"><i /> {t.heroEyebrow}</div>
            <h1>
              {t.heroTitle[0]}
              <br />
              {t.heroTitle[1]}
              <br />
              <span className="hero-accent">{t.heroTitle[2]}</span>
            </h1>
            <p>{t.heroCopy}</p>
            <div className="hero-actions">
              <a className="primary-cta" href="#shop">
                {t.heroPrimary} <Icon name="arrow" />
              </a>
              <a className="secondary-cta" href="#lookbook">
                {t.heroSecondary}
              </a>
            </div>
            <div className="specs">
              {t.specs.map(([value, label]) => (
                <span key={label}><b>{value}</b> {label}</span>
              ))}
            </div>
          </div>
          <div className="scroll-note">{t.scrollNote} <span>↓</span></div>
        </section>

        <section className="drop-section" id="drop">
          <div className="section-kicker">
            <span>{t.dropKicker[0]}</span>
            <span>{t.dropKicker[1]}</span>
          </div>
          <div className="drop-layout">
            <div>
              <h2>{t.dropTitle[0]}<br />{t.dropTitle[1]}</h2>
              <p>{t.dropCopy}</p>
            </div>
            <DropTimer ariaLabel={t.timerLabel} labels={t.timer} />
          </div>
        </section>

        <section className="shop-section" id="shop">
          <div className="section-heading">
            <div>
              <span className="eyebrow"><i /> {t.shopEyebrow}</span>
              <h2>{t.shopTitle[0]}<br />{t.shopTitle[1]}</h2>
            </div>
            <p>{t.shopCopy}</p>
          </div>
          <CategoryFilter active={filter} count={visibleProducts.length} onChange={setFilter} t={t} />
          <div className="product-grid" key={filter}>
            {visibleProducts.map((product, index) => (
              <ProductCard
                added={addedId === product.id}
                index={index}
                key={product.id}
                lang={lang}
                onAdd={() => addToCart(product)}
                onPreview={() => setPreview(product)}
                onSelectSize={(size) => setSelectedSizes((current) => ({ ...current, [product.id]: size }))}
                onToggleWishlist={() => toggleWishlist(product.id)}
                product={product}
                selectedSize={selectedSizes[product.id]}
                t={t}
                wished={wishlist.includes(product.id)}
              />
            ))}
          </div>
          <a className="text-link" href="#shop" onClick={() => setFilter("all")}>
            {t.viewAll} <Icon name="arrow" />
          </a>
        </section>

        <section className="fabric-section" id="about">
          <div className="fabric-image">
            <img alt={t.fabricAlt} src={photos.architecture} />
            <span>{t.fabricFig}</span>
          </div>
          <div className="fabric-copy">
            <span className="chapter">{t.fabricChapter}</span>
            <h2>{t.fabricTitle[0]}<br />{t.fabricTitle[1]}</h2>
            <p>{t.fabricCopy}</p>
            <div className="metrics">
              {t.metrics.map(([value, label]) => (
                <div key={label}><strong>{value}</strong><span>{label}</span></div>
              ))}
            </div>
          </div>
        </section>

        <section className="lookbook" id="lookbook">
          <img alt={t.lookAlt} src={looks[look].image} />
          <div className="lookbook-overlay" />
          <div className="lookbook-top">
            <span>{t.lookTop}</span>
            <span>{String(look + 1).padStart(2, "0")} / {String(looks.length).padStart(2, "0")}</span>
          </div>
          <div className="lookbook-copy">
            <span>LOOK {looks[look].number}</span>
            <h2>{looks[look].title}</h2>
            <p>{looks[look].copy}</p>
          </div>
          <div className="lookbook-controls">
            <Action label={t.prevLook} onClick={() => setLook((look - 1 + looks.length) % looks.length)}>
              <Icon name="arrow" />
            </Action>
            <Action label={t.nextLook} onClick={() => setLook((look + 1) % looks.length)}>
              <Icon name="arrow" />
            </Action>
          </div>
        </section>

        <ManifestoSection t={t.manifesto} />

        <ArchiveSection t={t.archive} />

        <section className="newsletter">
          <span className="chapter">{t.newsChapter}</span>
          <h2>{t.newsTitle[0]}<br />{t.newsTitle[1]}</h2>
          <p>{t.newsCopy}</p>
          <form onSubmit={(event) => event.preventDefault()}>
            <input aria-label={t.emailLabel} placeholder={t.emailPlaceholder} type="email" />
            <button type="submit">{t.join} <Icon name="arrow" /></button>
          </form>
        </section>
      </main>

      <footer>
        <div className="footer-top">
          <Logo />
          <div className="footer-links">
            <div>
              <span>{t.footer.explore}</span>
              <a href="#shop">{t.footer.exploreLinks[0]}</a>
              <a href="#shop">{t.footer.exploreLinks[1]}</a>
              <a href="#lookbook">{t.footer.exploreLinks[2]}</a>
            </div>
            <div>
              <span>{t.footer.help}</span>
              {t.footer.helpLinks.map((link) => <a href="#top" key={link}>{link}</a>)}
            </div>
            <div>
              <span>{t.footer.follow}</span>
              <a href="#top">Instagram ↗</a><a href="#top">Are.na ↗</a><a href="#top">Journal ↗</a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          {t.footer.bottom.map((item) => <span key={item}>{item}</span>)}
        </div>
      </footer>

      <div className={cartOpen ? "drawer-backdrop open" : "drawer-backdrop"} onClick={() => setCartOpen(false)} />
      <aside className={cartOpen ? "cart-drawer open" : "cart-drawer"} aria-label={t.cart.label}>
        <div className="drawer-header">
          <div>
            <span>{t.cart.title}</span>
            <small>{t.cart.items(cartCount)}</small>
          </div>
          <Action label={t.cart.close} onClick={() => setCartOpen(false)}>
            <Icon name="close" size={22} />
          </Action>
        </div>

        <div className="shipping-progress">
          <div>
            <span>
              {shippingRemaining > 0 ? t.cart.shippingLeft(formatPrice(shippingRemaining, lang)) : t.cart.shippingFree}
            </span>
            <strong>{Math.min(100, (subtotal / 2000) * 100).toFixed(0)}%</strong>
          </div>
          <div className="progress-track">
            <span style={{ width: `${Math.min(100, (subtotal / 2000) * 100)}%` }} />
          </div>
        </div>

        <div className="cart-items">
          {cart.length === 0 ? (
            <div className="empty-cart">
              <Icon name="bag" size={34} />
              <h3>{t.cart.emptyTitle}</h3>
              <p>{t.cart.emptyCopy}</p>
              <Action onClick={() => setCartOpen(false)}>{t.cart.back}</Action>
            </div>
          ) : (
            cart.map((item) => (
              <div className="cart-item" key={`${item.product.id}-${item.size}`}>
                <div className="cart-thumb">
                  <img alt={item.product.copy[lang].name} src={item.product.image} />
                </div>
                <div className="cart-item-copy">
                  <span>{t.filters[item.product.category]} / {t.cart.size} {item.size}</span>
                  <h3>{item.product.copy[lang].name}</h3>
                  <strong>{formatPrice(item.product.price, lang)}</strong>
                  <div className="quantity">
                    <Action label={t.cart.decrease} onClick={() => updateQuantity(item.product.id, item.size, -1)}>
                      <Icon name="minus" size={14} />
                    </Action>
                    <span>{item.quantity}</span>
                    <Action label={t.cart.increase} onClick={() => updateQuantity(item.product.id, item.size, 1)}>
                      <Icon name="plus" size={14} />
                    </Action>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="drawer-footer">
          <div><span>{t.cart.subtotal}</span><strong>{formatPrice(subtotal, lang)}</strong></div>
          <small>{t.cart.taxes}</small>
          <Action className="checkout" onClick={() => setCartOpen(false)}>
            {t.cart.checkout} <Icon name="arrow" />
          </Action>
          <span className="secure-note">{t.cart.secure}</span>
        </div>
      </aside>

      <div className={wishlistOpen ? "drawer-backdrop open" : "drawer-backdrop"} onClick={() => setWishlistOpen(false)} />
      <aside aria-label={t.wishlistPanel.label} className={wishlistOpen ? "cart-drawer wish-drawer open" : "cart-drawer wish-drawer"}>
        <div className="drawer-header">
          <div>
            <span>{t.wishlistPanel.title}</span>
            <small>{t.wishlistPanel.items(wishlist.length)}</small>
          </div>
          <Action label={t.wishlistPanel.close} onClick={() => setWishlistOpen(false)}>
            <Icon name="close" size={22} />
          </Action>
        </div>
        <div className="cart-items">
          {wishlist.length === 0 ? (
            <div className="empty-cart">
              <Icon name="heart" size={34} />
              <h3>{t.wishlistPanel.emptyTitle}</h3>
              <p>{t.wishlistPanel.emptyCopy}</p>
              <Action onClick={() => setWishlistOpen(false)}>{t.wishlistPanel.back}</Action>
            </div>
          ) : (
            wishlist
              .map((id) => products.find((item) => item.id === id))
              .filter((item): item is Product => Boolean(item))
              .map((item) => (
                <div className="cart-item" key={item.id}>
                  <div
                    className="cart-thumb wish-thumb"
                    onClick={() => {
                      setWishlistOpen(false);
                      setPreview(item);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        setWishlistOpen(false);
                        setPreview(item);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                  >
                    <img alt={item.copy[lang].name} src={item.image} />
                  </div>
                  <div className="cart-item-copy">
                    <span>{t.filters[item.category]}</span>
                    <h3>{item.copy[lang].name}</h3>
                    <strong>{formatPrice(item.price, lang)}</strong>
                    <div className="wish-actions">
                      <Action
                        className="wish-btn"
                        onClick={() => {
                          setWishlistOpen(false);
                          setPreview(item);
                        }}
                      >
                        {t.wishlistPanel.view} <Icon name="arrow" size={14} />
                      </Action>
                      <Action className="wish-btn ghost" onClick={() => toggleWishlist(item.id)}>
                        {t.wishlistPanel.remove}
                      </Action>
                    </div>
                  </div>
                </div>
              ))
          )}
        </div>
      </aside>

      {preview && (
        <ProductModal
          lang={lang}
          onAdd={(product, size) => {
            addToCart(product, size);
            setPreview(null);
          }}
          onClose={() => setPreview(null)}
          onOpenProduct={setPreview}
          onToggleWishlist={toggleWishlist}
          product={preview}
          key={preview.id}
          t={t}
          wished={wishlist.includes(preview.id)}
        />
      )}

      <AiAssistant lang={lang} t={t.assistant} />
    </div>
  );
}
