"use client";

import { useState } from "react";
import type { Dict } from "@/lib/i18n";

export function ManifestoSection({ t }: { t: Dict["manifesto"] }) {
  const [active, setActive] = useState(0);

  return (
    <section aria-labelledby="manifesto-title" className="manifesto-section" id="manifesto">
      <div className="section-kicker">
        <span>{t.tagline}</span>
        <span>50.0809° N / 14.4511° E</span>
      </div>

      <div className="manifesto-layout">
        <div className="manifesto-intro">
          <div className="manifesto-meta">
            <span className="manifesto-badge">{t.badge}</span>
            <span className="chapter">{t.chapter}</span>
          </div>
          <h2 id="manifesto-title">
            {t.title[0]}
            <br />
            {t.title[1]}
            <br />
            <span className="manifesto-accent">{t.title[2]}</span>
          </h2>
          {t.story.map((paragraph) => (
            <p key={paragraph.slice(0, 24)}>{paragraph}</p>
          ))}
        </div>

        <figure className="manifesto-figure">
          <img alt={t.imageAlt} src="/lookbook/zizkov-tubus.png" />
          <figcaption>OBR. 001 / TUBUS × 3</figcaption>
        </figure>
      </div>

      <ul aria-label={t.featuresLabel} className="manifesto-features">
        {t.features.map((feature, index) => (
          <li key={feature.title}>
            <button
              aria-pressed={active === index}
              className={active === index ? "manifesto-feature active" : "manifesto-feature"}
              onClick={() => setActive(index)}
              onFocus={() => setActive(index)}
              onMouseEnter={() => setActive(index)}
              type="button"
            >
              <span className="manifesto-index">{String(index + 1).padStart(2, "0")}</span>
              <strong>{feature.title}</strong>
              <span className="manifesto-feature-copy">{feature.copy}</span>
              <i aria-hidden="true" className="manifesto-bar" />
            </button>
          </li>
        ))}
      </ul>

      <dl className="manifesto-specs">
        {t.specs.map(([label, value]) => (
          <div key={label}>
            <dt>{label}:</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
