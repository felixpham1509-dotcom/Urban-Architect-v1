"use client";

import { useChat } from "@ai-sdk/react";
import { useEffect, useRef, useState } from "react";
import type { Dict, Lang } from "@/lib/i18n";

export function AiAssistant({ lang, t }: { lang: Lang; t: Dict["assistant"] }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const { messages, sendMessage, status, error } = useChat();
  const listRef = useRef<HTMLDivElement>(null);
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const send = (text: string) => {
    const value = text.trim();
    if (!value || busy) return;
    sendMessage({ text: value }, { body: { lang } });
    setInput("");
  };

  return (
    <div className="assistant">
      {open && (
        <section aria-label={t.title} className="assistant-panel" role="dialog">
          <header className="assistant-header">
            <div>
              <span>{t.title}</span>
              <small><i /> {t.status} / {lang.toUpperCase()}</small>
            </div>
            <button aria-label={t.close} className="assistant-icon" onClick={() => setOpen(false)} type="button">
              <svg aria-hidden="true" fill="none" height="18" viewBox="0 0 24 24" width="18">
                <path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
              </svg>
            </button>
          </header>

          <div aria-live="polite" className="assistant-messages" ref={listRef}>
            <div className="assistant-msg bot">
              <span>{t.bot}</span>
              <p>{t.intro}</p>
            </div>
            {messages.length === 0 && (
              <div className="assistant-suggestions">
                {t.suggestions.map((s) => (
                  <button key={s} onClick={() => send(s)} type="button">{s}</button>
                ))}
              </div>
            )}
            {messages.map((message) => (
              <div className={`assistant-msg ${message.role === "user" ? "user" : "bot"}`} key={message.id}>
                <span>{message.role === "user" ? t.you : t.bot}</span>
                <p>
                  {message.parts.map((part, i) =>
                    part.type === "text" ? <span key={`${message.id}-${i}`}>{part.text}</span> : null,
                  )}
                </p>
              </div>
            ))}
            {status === "submitted" && <div className="assistant-thinking">{t.thinking}</div>}
            {error && <div className="assistant-error">{t.error}</div>}
          </div>

          <form
            className="assistant-form"
            onSubmit={(event) => {
              event.preventDefault();
              send(input);
            }}
          >
            <input
              aria-label={t.placeholder}
              autoFocus
              maxLength={500}
              onChange={(event) => setInput(event.target.value)}
              placeholder={t.placeholder}
              value={input}
            />
            <button aria-label={t.send} disabled={busy || !input.trim()} type="submit">
              <svg aria-hidden="true" fill="none" height="16" viewBox="0 0 24 24" width="16">
                <path d="M5 12h14m-5-5 5 5-5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
              </svg>
            </button>
          </form>
        </section>
      )}

      <button
        aria-expanded={open}
        className={open ? "assistant-trigger open" : "assistant-trigger"}
        onClick={() => setOpen(!open)}
        type="button"
      >
        <i />
        {t.trigger}
      </button>
    </div>
  );
}
