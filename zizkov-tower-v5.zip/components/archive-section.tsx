"use client";

import { useState } from "react";
import type { Dict } from "@/lib/i18n";

const archiveMeta = [
  { drop: "001", edition: 300, image: "/products/mikina-spectrum-tower.png" },
  { drop: "002", edition: 200, image: "/archive/raw-concrete-tee.png" },
  { drop: "003", edition: 150, image: "/archive/monolith-cap.png" },
];

export function ArchiveSection({ t }: { t: Dict["archive"] }) {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section aria-labelledby="archive-title" className="archive-section" id="archive">
      <div className="section-heading">
        <div>
          <span className="eyebrow">
            <i /> {t.chapter}
          </span>
          <h2 id="archive-title">
            {t.title[0]}
            <br />
            {t.title[1]}
          </h2>
        </div>
        <div className="archive-aside">
          <span className="archive-badge">
            <i aria-hidden="true" /> {t.badge}
          </span>
          <p>{t.copy}</p>
        </div>
      </div>

      <div className="archive-grid">
        {t.items.map((item, index) => {
          const meta = archiveMeta[index];
          const isOpen = open === index;
          const panelId = `archive-panel-${meta.drop}`;
          return (
            <article className={isOpen ? "archive-card open" : "archive-card"} key={meta.drop}>
              <div className="archive-image">
                <img alt={`${item.title} – Drop #${meta.drop}`} src={meta.image} />
                <span className="archive-stamp">{t.soldOut}</span>
                <span className="archive-drop">DROP #{meta.drop}</span>
              </div>
              <div className="archive-copy">
                <div className="archive-row">
                  <span>{item.type}</span>
                  <span>{item.year}</span>
                </div>
                <h3>{item.title}</h3>
                <div className="archive-row">
                  <span>
                    {t.edition} {meta.edition} {t.pieces}
                  </span>
                  <b>
                    {meta.edition} / {meta.edition}
                  </b>
                </div>
                <div aria-hidden="true" className="archive-meter">
                  <span />
                </div>
                <button
                  aria-controls={panelId}
                  aria-expanded={isOpen}
                  className="archive-toggle"
                  onClick={() => setOpen(isOpen ? null : index)}
                  type="button"
                >
                  {isOpen ? t.hide : t.details}
                  <span aria-hidden="true">{isOpen ? "−" : "+"}</span>
                </button>
                <div className="archive-panel" hidden={!isOpen} id={panelId}>
                  <p>{item.copy}</p>
                  <span className="archive-disabled">{t.notify}</span>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
