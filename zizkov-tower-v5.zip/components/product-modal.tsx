"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { formatPrice, products, type Dict, type Lang, type Product } from "@/lib/i18n";

type SectionKey = "material" | "details" | "care";

function MiniIcon({ name, size = 18 }: { name: "close" | "heart" | "bag" | "plus" | "minus" | "arrow" | "left" | "right" | "ruler"; size?: number }) {
  const paths: Record<typeof name, React.ReactNode> = {
    close: (
      <>
        <path d="m6 6 12 12" />
        <path d="m18 6-12 12" />
      </>
    ),
    heart: <path d="M20.8 5.7a5.5 5.5 0 0 0-7.8 0L12 6.8l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 22l7.8-7.4 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    bag: (
      <>
        <path d="M5 8h14l-1 12H6L5 8Z" />
        <path d="M9 8V6a3 3 0 0 1 6 0v2" />
      </>
    ),
    plus: (
      <>
        <path d="M5 12h14" />
        <path d="M12 5v14" />
      </>
    ),
    minus: <path d="M5 12h14" />,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    left: <path d="m14 6-6 6 6 6" />,
    right: <path d="m10 6 6 6-6 6" />,
    ruler: (
      <>
        <path d="m4 15 11-11 5 5L9 20l-5-5Z" />
        <path d="m8 11 2 2m1-5 2 2m-7 4 2 2" />
      </>
    ),
  };
  return (
    <svg aria-hidden="true" fill="none" height={size} viewBox="0 0 24 24" width={size}>
      <g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6">
        {paths[name]}
      </g>
    </svg>
  );
}

const sizeChart: Record<"hoodies" | "tees", { width: number[]; length: number[] }> = {
  hoodies: { width: [58, 61, 64, 67, 70], length: [68, 70, 72, 74, 76] },
  tees: { width: [56, 59, 62, 65, 68], length: [70, 72, 74, 76, 78] },
};

const zoomOrigin: Record<Product["category"], string> = {
  hoodies: "50% 56%",
  tees: "50% 46%",
  accessories: "50% 50%",
};

export function ProductModal({
  lang,
  onAdd,
  onClose,
  onOpenProduct,
  onToggleWishlist,
  product,
  t,
  wished,
}: {
  lang: Lang;
  onAdd: (product: Product, size: string) => void;
  onClose: () => void;
  onOpenProduct: (product: Product) => void;
  onToggleWishlist: (productId: number) => void;
  product: Product;
  t: Dict;
  wished: boolean;
}) {
  const m = t.modal;
  const copy = product.copy[lang];
  const rootRef = useRef<HTMLDivElement>(null);
  const [slide, setSlide] = useState(0);
  const [size, setSize] = useState<string | null>(product.sizes.length === 1 ? product.sizes[0] : null);
  const [open, setOpen] = useState<SectionKey | null>("material");
  const [guideOpen, setGuideOpen] = useState(false);
  const [nudge, setNudge] = useState(false);

  const slides = useMemo(
    () => [
      { src: product.image, position: product.imagePosition, scale: 1, origin: "50% 50%", mono: false, label: m.gallery[0] },
      { src: product.image, position: product.imagePosition, scale: 2.1, origin: zoomOrigin[product.category], mono: false, label: m.gallery[1] },
      { src: "/lookbook/zizkov-tubus.png", position: "50% 40%", scale: 1, origin: "50% 50%", mono: true, label: m.gallery[2] },
    ],
    [product, m.gallery],
  );

  const related = useMemo(() => {
    const others = products.filter((item) => item.id !== product.id);
    const sameCategory = others.filter((item) => item.category === product.category);
    const rest = others.filter((item) => item.category !== product.category);
    return [...sameCategory, ...rest].slice(0, 4);
  }, [product]);

  const goTo = (index: number) => setSlide((index + slides.length) % slides.length);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowLeft") setSlide((value) => (value - 1 + 3) % 3);
      if (event.key === "ArrowRight") setSlide((value) => (value + 1) % 3);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    rootRef.current?.scrollTo({ top: 0 });
  }, [product.id]);

  const section = m.sections[product.category];
  const chart = product.category === "accessories" ? null : sizeChart[product.category];
  const stock = product.label === "LIMITED" || product.label === "SET" ? m.stockLast : product.label === "NEW" ? m.stockNew : m.stock;

  const handleAdd = () => {
    if (!size) {
      setNudge(true);
      window.setTimeout(() => setNudge(false), 700);
      return;
    }
    onAdd(product, size);
  };

  const sections: Array<{ key: SectionKey; title: string; body: React.ReactNode }> = [
    { key: "material", title: m.accordion.material, body: <p>{section.material}</p> },
    {
      key: "details",
      title: m.accordion.details,
      body: (
        <ul>
          {section.details.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      ),
    },
    { key: "care", title: m.accordion.care, body: <p>{section.care}</p> },
  ];

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        aria-label={copy.name}
        aria-modal="true"
        className="product-modal pm"
        onClick={(event) => event.stopPropagation()}
        ref={rootRef}
        role="dialog"
      >
        <button aria-label={m.close} className="pm-close" onClick={onClose} type="button">
          <MiniIcon name="close" size={20} />
        </button>

        <div className="pm-top">
          <div className="pm-gallery">
            <div className="pm-stage">
              {slides.map((item, index) => (
                <img
                  alt={`${copy.name} — ${item.label}`}
                  className={`pm-slide${index === slide ? " active" : ""}${item.mono ? " mono" : ""}`}
                  key={item.label}
                  src={item.src}
                  style={{ objectPosition: item.position, transform: `scale(${item.scale})`, transformOrigin: item.origin }}
                />
              ))}
              <span className="pm-counter">
                {slide + 1} / {slides.length}
              </span>
              <div className="pm-arrows">
                <button aria-label={m.prev} onClick={() => goTo(slide - 1)} type="button">
                  <MiniIcon name="left" size={18} />
                </button>
                <button aria-label={m.next} onClick={() => goTo(slide + 1)} type="button">
                  <MiniIcon name="right" size={18} />
                </button>
              </div>
            </div>
            <div className="pm-thumbs" role="tablist">
              {slides.map((item, index) => (
                <button
                  aria-label={item.label}
                  aria-selected={index === slide}
                  className={index === slide ? "pm-thumb active" : "pm-thumb"}
                  key={item.label}
                  onClick={() => setSlide(index)}
                  role="tab"
                  type="button"
                >
                  <img
                    alt=""
                    className={item.mono ? "mono" : ""}
                    src={item.src}
                    style={{ objectPosition: item.position, transform: `scale(${item.scale})`, transformOrigin: item.origin }}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="pm-info">
            <div className="pm-meta">
              <span>{m.eyebrow}</span>
              <i aria-hidden="true" />
              <b className="pm-stock">
                <em /> {stock}
              </b>
            </div>

            <h2 className="pm-title">{copy.name}</h2>

            <div className="pm-price-row">
              <strong>{formatPrice(product.price, lang)}</strong>
              <button
                aria-label={t.addWishlist}
                aria-pressed={wished}
                className={wished ? "pm-heart active" : "pm-heart"}
                onClick={() => onToggleWishlist(product.id)}
                type="button"
              >
                <MiniIcon name="heart" size={17} />
              </button>
            </div>

            <p className="pm-desc">{copy.description}</p>

            <div className="pm-size-head">
              <span>{m.chooseSize}</span>
              {chart && (
                <button aria-expanded={guideOpen} className="pm-guide-link" onClick={() => setGuideOpen(!guideOpen)} type="button">
                  <MiniIcon name="ruler" size={14} /> {m.sizeGuide}
                </button>
              )}
            </div>

            {chart && guideOpen && (
              <table className="pm-guide">
                <thead>
                  <tr>
                    <th />
                    {product.sizes.map((s) => (
                      <th key={s}>{s}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>{m.chestWidth}</th>
                    {chart.width.map((v, i) => (
                      <td key={i}>{v}</td>
                    ))}
                  </tr>
                  <tr>
                    <th>{m.length}</th>
                    {chart.length.map((v, i) => (
                      <td key={i}>{v}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            )}

            <div aria-label={m.chooseSize} className={nudge ? "pm-sizes nudge" : "pm-sizes"} role="radiogroup">
              {product.sizes.map((s) => (
                <button
                  aria-checked={size === s}
                  className={size === s ? "pm-size active" : "pm-size"}
                  key={s}
                  onClick={() => setSize(s)}
                  role="radio"
                  type="button"
                >
                  {s}
                </button>
              ))}
            </div>

            <button className={size ? "pm-cta ready" : "pm-cta"} onClick={handleAdd} type="button">
              {size ? (
                <>
                  {t.addToCart} <MiniIcon name="bag" size={18} />
                </>
              ) : (
                m.selectSize
              )}
            </button>

            <div className="pm-accordion">
              {sections.map((item) => {
                const isOpen = open === item.key;
                return (
                  <div className={isOpen ? "pm-acc open" : "pm-acc"} key={item.key}>
                    <button
                      aria-controls={`pm-panel-${item.key}`}
                      aria-expanded={isOpen}
                      className="pm-acc-head"
                      onClick={() => setOpen(isOpen ? null : item.key)}
                      type="button"
                    >
                      <span>{item.title}</span>
                      <MiniIcon name={isOpen ? "minus" : "plus"} size={16} />
                    </button>
                    <div className="pm-acc-body" hidden={!isOpen} id={`pm-panel-${item.key}`}>
                      {item.body}
                    </div>
                  </div>
                );
              })}
            </div>

            <p className="pm-shipping">{m.shipping}</p>
          </div>
        </div>

        <section aria-label={m.related} className="pm-related">
          <div className="pm-related-head">
            <div>
              <span>{m.relatedKicker}</span>
              <h3>{m.related}</h3>
            </div>
          </div>
          <div className="pm-related-grid">
            {related.map((item) => (
              <button className="pm-rel-card" key={item.id} onClick={() => onOpenProduct(item)} type="button">
                <span className="pm-rel-image">
                  <img alt={item.copy[lang].name} src={item.image} style={{ objectPosition: item.imagePosition }} />
                </span>
                <span className="pm-rel-copy">
                  <small>{t.filters[item.category]}</small>
                  <b>{item.copy[lang].name}</b>
                  <strong>{formatPrice(item.price, lang)}</strong>
                </span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
